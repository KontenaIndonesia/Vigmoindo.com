A Pen created at CodePen.io. You can find this one at https://codepen.io/iPhoneK1LLA/pen/JdLvoq.

 Flat Payment Form designed with HAML HTML Preprocessor and Less CSS Preprocessor